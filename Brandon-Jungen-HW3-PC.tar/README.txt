Same setup as other projects where if you want a jar then run "gradle build" in command.
This will build the path build/libs/'name of directory'.jar for the jar.

The only class that is not a part of the map reduce is Average under cs455.hadoop.utils.Average.
This class is a writable class that I used to help with storing the values to calulate average in many of the reducers.
